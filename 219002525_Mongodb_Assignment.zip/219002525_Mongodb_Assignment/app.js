//require the express package
const express = require('express')
const mongodb = require('mongodb')
const {saveEmployee,fetchEmployeeDetails} = require('./routes/employees')
const { saveEmployeeTodoList, fetchEmployeeTodoList } = require('./routes/todolist')

//initialize the mongodb client
const MongoClient = mongodb.MongoClient

const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'employeedb'
var db;

//create the express app
const app = express()

app.use(express.json())

//create a port to listen on and connect mongodb
app.listen(3000,()=>{
    MongoClient.connect(connectionURL,{useNewUrlParser:true},(error,client)=>{
        if(error){
            return console.log('Unable to connect to server')
        }

        db = client.db(databaseName)
    })
})

app.get('/employeeList',(req,res)=>{
    fetchEmployeeDetails(db,(error,result)=>{
        if(error) return res.send(error)
        res.send(result)   
    })
})

app.get('/todoList',(req,res)=>{
    fetchEmployeeDetails(db, (error, result) => {
        if (error) return res.send(error)
        res.send(result)
    })
})

app.post('/addEmployee', (req,res) => {
    saveEmployee(req.body, db, (error,result)=>{
        if (error) return res.send(error)
        res.send(result)
    })
})


app.post('/addtodoList',(req,res)=>{
saveEmployee(req.body, db, (error,result)=>{
        if (error) return res.send(error)
        res.send(result)
    })
})

app.set('view engine', 'ejs')

const employees = [
    {
        employeeID: "ESCL001",
        name: "Andoh Justice",
        position: "IT Manager"
    },
    {
        employeeID: "ESCL002",
        name: "Lilly Aidoo",
        position: "Secretory"
    },
    {
        employeeID: "ESCL003",
        name: "Nana Kofi",
        position: "Financial Controller"
    }
]

app.get('/',(req,res)=>{
    res.render('home',{employees})
})

app.use(express.static(__dirname + '/public'))
