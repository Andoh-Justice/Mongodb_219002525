const mongodb = require('mongodb')
const MongoClient = mongodb.MongoClient
const connectionURL = 'mongodb://127.0.0.1:27017'
const databaseName = 'employeedb'
MongoClient.connect(connectionURL, { userNewUrlParser: true }, (error, clint) => {
    if (error) {
        return console.log('Unable to connect to server')
    }
    console.log('Connection Successful')
})